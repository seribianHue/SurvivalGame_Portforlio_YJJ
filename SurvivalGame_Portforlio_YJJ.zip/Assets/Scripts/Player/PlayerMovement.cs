using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] public float _moveSpeed = 5f;
    [SerializeField] public float _rotSpeed = 2f;

    private void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        transform.position += transform.forward * z * _moveSpeed * Time.deltaTime;
        transform.position += transform.right * x * _moveSpeed * Time.deltaTime;

        transform.Rotate(0f, Input.GetAxis("Mouse X") * _rotSpeed, 0f, Space.World);
    }
}
